package com.app.entities;

public enum Role {
	ADMIN, BLOGGER,COMMENTER
}
