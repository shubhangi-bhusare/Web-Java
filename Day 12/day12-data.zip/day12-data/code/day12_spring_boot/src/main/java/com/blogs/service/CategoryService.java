package com.blogs.service;

import java.util.List;

import com.blogs.entities.Category;

public interface CategoryService {
	//add a method to get list of categories
	List<Category> getAllCategories();
}
