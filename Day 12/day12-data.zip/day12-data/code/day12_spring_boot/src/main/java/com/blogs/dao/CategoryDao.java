package com.blogs.dao;

import java.util.List;

import com.blogs.entities.Category;

public interface CategoryDao {
	List<Category> listAllCategories();
}
